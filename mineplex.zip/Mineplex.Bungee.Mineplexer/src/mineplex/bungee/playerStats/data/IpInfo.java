package mineplex.bungee.playerStats.data;

public class IpInfo
{
	public int id;
	public String ipAddress;
}

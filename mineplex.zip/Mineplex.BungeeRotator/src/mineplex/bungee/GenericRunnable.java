package mineplex.bungee;

public interface GenericRunnable<T>
{
	void run(T t);
}

package mineplex.chestConverter;

public interface GenericRunnable<T>
{
	void run(T t);
}

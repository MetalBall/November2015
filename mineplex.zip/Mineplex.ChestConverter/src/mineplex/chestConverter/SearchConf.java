package mineplex.chestConverter;

public class SearchConf
{
	public SearchConf(int idIndex, int count)
	{
		IdIndex = idIndex;
		Count = count;
	}

	public int IdIndex;
	public int Count;
}

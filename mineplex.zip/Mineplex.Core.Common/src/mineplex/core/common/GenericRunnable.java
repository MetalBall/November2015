package mineplex.core.common;

public interface GenericRunnable<T>
{
	void run(T t);
}

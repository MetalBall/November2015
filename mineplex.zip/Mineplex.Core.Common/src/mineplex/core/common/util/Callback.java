package mineplex.core.common.util;

public interface Callback<T>
{
	public void run(T data);
}

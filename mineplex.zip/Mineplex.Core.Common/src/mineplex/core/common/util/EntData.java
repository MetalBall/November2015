package mineplex.core.common.util;

import org.bukkit.entity.EntityType;

public class EntData 
{
	public String Name;
	public EntityType Type;
	public double Height;
	public double Scale;
	
	public EntData(String name, EntityType type, double height, double scale)
	{
		
	}
}

package mineplex.core.common.util;

public interface RunnableStatus
{
	public boolean run();
}

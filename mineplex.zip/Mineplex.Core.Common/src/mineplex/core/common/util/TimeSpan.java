package mineplex.core.common.util;

public class TimeSpan
{
	public static final long DAY = 86400000;
	public static final long HOUR = 3600000;
	public static final long MINUTE = 60000;
	public static final long SECOND = 1000;
}

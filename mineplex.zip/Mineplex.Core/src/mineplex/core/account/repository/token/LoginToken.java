package mineplex.core.account.repository.token;

public class LoginToken
{
    public String Name;
    public String IpAddress = "0.0.0.0";
    public String MacAddress = "00-00-00-00-00-00-00-00";
	public String Uuid;
}

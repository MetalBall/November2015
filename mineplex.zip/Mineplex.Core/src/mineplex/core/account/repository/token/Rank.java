package mineplex.core.account.repository.token;

public class Rank 
{
	public int RankId;
	
	public String Name;
}

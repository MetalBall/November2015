package mineplex.core.account.repository.token;

public class RankUpdateToken
{
	public String Name;
	public String Rank;
	public boolean Perm;
}

package mineplex.core.antihack;

import org.bukkit.entity.Player;

public interface Detector 
{
	public void Reset(Player player);
}
